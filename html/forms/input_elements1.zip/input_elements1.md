#Input Elements
*text - accepts any kind of text
*password - accepts text and keeps it hidden from the screen
*email - forces email format 
*date - accepts input as a date
*check box - lets user select 0 or more choices
*select name - pull down menu of options
